numbers_seq <- 20:50

mean_20_to_60 <- mean(20:60)

sum_51_to_91 <- sum(51:91)

cat("Sequence of numbers from 20 to 50:", numbers_seq, "\n")
cat("Mean of numbers from 20 to 60:", mean_20_to_60, "\n")
cat("Sum of numbers from 51 to 91:", sum_51_to_91, "\n")