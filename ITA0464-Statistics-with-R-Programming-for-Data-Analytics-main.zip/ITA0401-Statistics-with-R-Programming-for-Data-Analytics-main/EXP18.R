vec1 <- c(1, 2, 3, 4, 5, 6)
vec2 <- c(7, 8, 9, 10, 11, 12)
values <- c(vec1, vec2)
my_array <- array(values, dim = c(3, 3, 2))
my_array