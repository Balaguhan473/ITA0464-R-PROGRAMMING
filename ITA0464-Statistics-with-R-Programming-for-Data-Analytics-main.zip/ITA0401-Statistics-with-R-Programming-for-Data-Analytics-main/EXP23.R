v <- 1:24
a <- array(v, dim = c(4, 3, 2))
print(a)