v <- seq(52, 80, 2)
a <- array(v, dim = c(5, 3))
print(a)