add <- function(x,y){
  return(x+y)
}

sub <- function(x,y){
  return(x-y)
}

mult <- function(x,y){
  return(x*y)
}

div <- function(x,y){
  return(x/y)
}
add(9,3)
sub(3,4)
mult(3,4)
div(9,3)
